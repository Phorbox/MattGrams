#ifndef   CALCULATOR_H
#define   CALCULATOR_H


void calcAdd(double *running, double operating);
void calcSubtract(double *running, double operating);
double calcMultiply(double running, double operating);
double calcDivide(double running, double operating);
void calculator();

#endif