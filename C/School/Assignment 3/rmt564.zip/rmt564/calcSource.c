#include <stdio.h>
#include "calculator.h"

/*
 *	calcSource.C
 *	Assignment 3
 *	Matthew Henderson
 *	This program operates as a basic calculator
 *	it will perform basic arithmatic operations 
 *  and will output a running total.
 */

int main(int argc, char *argv[])
{
	calculator();
	return 0;
}
